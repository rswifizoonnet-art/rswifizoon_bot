<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<rsadmin','mikhmon>|>qqSTnJ6bpg==');

$data['Offline-❤️-RS-WiFi-ZOON-❤️'] = array ('1'=>'Offline-❤️-RS-WiFi-ZOON-❤️!1.1.1.1','Offline-❤️-RS-WiFi-ZOON-❤️@|@rsadmin','Offline-❤️-RS-WiFi-ZOON-❤️#|#qqSTnJ6bpg==','Offline-❤️-RS-WiFi-ZOON-❤️%❤️ RS WiFi ZOON ❤️','Offline-❤️-RS-WiFi-ZOON-❤️^rswifizoon.net','Offline-❤️-RS-WiFi-ZOON-❤️&TK','Offline-❤️-RS-WiFi-ZOON-❤️*10','Offline-❤️-RS-WiFi-ZOON-❤️(1','Offline-❤️-RS-WiFi-ZOON-❤️)','Offline-❤️-RS-WiFi-ZOON-❤️=10','Offline-❤️-RS-WiFi-ZOON-❤️@!@enable');




$data['Online-❤️-RS-WiFi-ZOON-❤️'] = array ('1'=>'Online-❤️-RS-WiFi-ZOON-❤️!67d408bcdce3.sn.mynetname.net','Online-❤️-RS-WiFi-ZOON-❤️@|@rsadmin','Online-❤️-RS-WiFi-ZOON-❤️#|#qqSTnJ6bpg==','Online-❤️-RS-WiFi-ZOON-❤️%❤️ RS WiFi ZOON ❤️','Online-❤️-RS-WiFi-ZOON-❤️^rswifizoon.net','Online-❤️-RS-WiFi-ZOON-❤️&TK','Online-❤️-RS-WiFi-ZOON-❤️*10','Online-❤️-RS-WiFi-ZOON-❤️(1','Online-❤️-RS-WiFi-ZOON-❤️)','Online-❤️-RS-WiFi-ZOON-❤️=10','Online-❤️-RS-WiFi-ZOON-❤️@!@enable');


$data['RemMik♥️-RS-WiFi-ZOON-♥️'] = array ('1'=>'RemMik♥️-RS-WiFi-ZOON-♥️!203.9.214.48:29209','RemMik♥️-RS-WiFi-ZOON-♥️@|@rsadmin','RemMik♥️-RS-WiFi-ZOON-♥️#|#qqSTnJ6bpg==','RemMik♥️-RS-WiFi-ZOON-♥️%♥️ RS WiFi ZOON ♥️','RemMik♥️-RS-WiFi-ZOON-♥️^rswifizoon.net','RemMik♥️-RS-WiFi-ZOON-♥️&TK','RemMik♥️-RS-WiFi-ZOON-♥️*10','RemMik♥️-RS-WiFi-ZOON-♥️(1','RemMik♥️-RS-WiFi-ZOON-♥️)','RemMik♥️-RS-WiFi-ZOON-♥️=10','RemMik♥️-RS-WiFi-ZOON-♥️@!@enable');